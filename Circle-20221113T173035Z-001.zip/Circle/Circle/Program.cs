﻿// Lớp Circle kế thừa lớp GeometricObject
// Trịnh Thuỳ Dung 20200093
using System;
using System.Xml;

namespace CircleClass
{
    class Program
    {
        public abstract class GeometricObject
        {
            protected string color;
            protected double weight;
            // Default construct 
            protected GeometricObject()
            {
                color = "white";
                weight = 1.0;
            }
            // Construct a geometric object
            protected GeometricObject(string color, double weight)
            {
                this.color = color;
                this.weight = weight;
            }
            public string Color
            {
                get
                {
                    return color;
                }
                set
                {
                    color = value;
                }
            }
            public double Weight
            {
                get
                {
                    return weight;

                }
                set
                {
                    weight = value;
                }
            }
            // Abstract method
            public abstract double findArea();
            // Abstract method
            public abstract double findPerimeter();
        }//end class GeometricObject

        public class Circle : GeometricObject
        {
            double radius;
            string color;
            double weight;

            public Circle(double radius, string color, double weight)
            {
                this.radius = radius;
                this.color = color;
                this.weight = weight;
            }

            // Cài đặt các hàm set-get
            public void setRadius(double radius)
            {
                this.radius = radius;
            }

            public double getRadius()
            {
                return radius;
            }

            public void setColor(string color)
            {
                this.color = color;
            }

            public string getColor()
            {
                return color;
            }

            public void setWeight(double weight)
            {
                this.weight = weight;
            }

            public double getWeight()
            {
                return weight;
            }

            // Phương thức ghi đè
            public override double findArea()
            {
                return 3.14 * radius * radius;
            }

            public override double findPerimeter()
            {
                return 2 * 3.14 * radius;
            }

            public override string ToString()
            {
                return $"This circle has:\nRadius = {getRadius()}\nColor = {getColor()}\nWeight = {getWeight()}";
            }
        }//end class Circle

        static void Main(string[] args)
        {
            // Trịnh Thuỳ Dung - 20200093
            // In đối tượng
            Circle circle1 = new Circle(2.5, "blue", 3.6);
            Console.WriteLine(circle1.ToString());
            Console.WriteLine("\n=========================");

            // Kiểm tra các hành vi của Circle class
            Console.WriteLine("Circle area: " + circle1.findArea());
            Console.WriteLine("Circle perimeter: " + circle1.findPerimeter());

            // Test lỗi: Tham số cung cấp không đủ (?)

            // Test lỗi: giá trị bán kính không phải giá trị số (?)

            Console.ReadKey();
        }//end Main

    }//end class Program
}//end namespace
